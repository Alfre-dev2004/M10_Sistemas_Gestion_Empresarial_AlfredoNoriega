{
    "name": "academy",
    "version": "1.0.0",
    "depends": ["base"],
    "data": [
        "views/views.xml",
    ],
    "application": True,
    "installable": True,
}