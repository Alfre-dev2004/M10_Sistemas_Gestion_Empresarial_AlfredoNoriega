from odoo import http
from odoo.http import request


class AcademyRoutes(http.Controller):

    @http.route(
        "/academy/courses",
        type="http",
        auth="public",
        methods=["GET"],
        website=False
    )
    def courses_endpoint(self, **payload):
        records = request.env["academy.course"].sudo().search([])
        titles = [label for _, label in records.name_get()]
        return "\n".join(titles)