from odoo import api, fields, models


class AcademyCourse(models.Model):
    _name = "academy.course"
    _description = "Academy Course"

    name = fields.Char(required=True)
    duration = fields.Integer()
    category = fields.Selection(
        [("online", "Online"), ("presencial", "Presencial")],
        default="presencial",
    )
    max_students = fields.Integer()
    enrollments = fields.One2many("academy.enrollment", "course_id")

    available_seats = fields.Integer(compute="_compute_available_seats", store=False)

    _sql_constraints = [
        ("academy_course_name_uniq", "unique(name)", "El nombre del curso debe ser único.")
    ]

    @api.depends("max_students", "enrollments.state")
    def _compute_available_seats(self):
        for item in self:
            confirmed_total = len(item.enrollments.filtered(lambda x: x.state == "confirmed"))
            limit_value = item.max_students or 0
            item.available_seats = limit_value - confirmed_total


class AcademyEnrollment(models.Model):
    _name = "academy.enrollment"
    _description = "Academy Enrollment"
    _order = "enrollment_date"

    student_name = fields.Char(required=True)
    enrollment_date = fields.Date(default=fields.Date.context_today)
    course_id = fields.Many2one("academy.course")
    state = fields.Selection(
        [("draft", "Draft"), ("confirmed", "Confirmed"), ("cancelled", "Cancelled")],
        default="draft",
    )

    def name_get(self):
        return [
            (row.id, f"[{row.course_id.name or ''}] - {row.student_name or ''}")
            for row in self
        ]